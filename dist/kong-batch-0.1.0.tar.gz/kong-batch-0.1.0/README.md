# Kong [![Build Status](https://travis-ci.com/paulgessinger/kong.svg?branch=master)](https://travis-ci.com/paulgessinger/kong) [![codecov](https://codecov.io/gh/paulgessinger/kong/branch/master/graph/badge.svg)](https://codecov.io/gh/paulgessinger/kong)

Kong is a batch job management software.
