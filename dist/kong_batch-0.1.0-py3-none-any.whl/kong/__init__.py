from . import state

get_instance = state.State.get_instance
