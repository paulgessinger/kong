import logging

from . import config

logger = logging.getLogger(config.APP_NAME)
